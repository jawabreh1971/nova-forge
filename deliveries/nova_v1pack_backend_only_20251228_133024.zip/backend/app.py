from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pathlib import Path

app = FastAPI(title="Nova Forge", version="1.0.0")

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

# Static mount (built frontend will be copied to backend/static)
STATIC_DIR = Path(__file__).parent / "static"
if STATIC_DIR.exists():
    app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")
