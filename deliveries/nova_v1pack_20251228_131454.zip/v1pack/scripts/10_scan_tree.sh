#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
echo "[10] scanning for backend/frontend..."
ROOT="$(pwd)"

# Detect frontend
FRONT=""
for d in frontend client web ui; do
  if [ -d "$ROOT/$d" ] && [ -f "$ROOT/$d/package.json" ]; then FRONT="$ROOT/$d"; break; fi
done
if [ -z "$FRONT" ]; then
  # fallback: search package.json candidates
  cand="$(find "$ROOT" -maxdepth 3 -name package.json 2>/dev/null | head -n 1 || true)"
  if [ -n "$cand" ]; then FRONT="$(dirname "$cand")"; fi
fi

# Detect backend
BACK=""
for d in backend server api; do
  if [ -d "$ROOT/$d" ]; then BACK="$ROOT/$d"; break; fi
done
if [ -z "$BACK" ]; then
  # fallback: look for requirements/pyproject
  cand="$(find "$ROOT" -maxdepth 3 -name requirements.txt -o -name pyproject.toml 2>/dev/null | head -n 1 || true)"
  if [ -n "$cand" ]; then BACK="$(dirname "$cand")"; fi
fi

echo "FRONT=$FRONT" | tee "$ROOT/v1pack/out/scan.env"
echo "BACK=$BACK"  | tee -a "$ROOT/v1pack/out/scan.env"

if [ -z "$FRONT" ]; then echo "[10] ERROR: frontend not found"; exit 1; fi
if [ -z "$BACK"  ]; then echo "[10] ERROR: backend not found"; exit 1; fi

echo "[10] OK: FRONT=$FRONT"
echo "[10] OK: BACK=$BACK"
